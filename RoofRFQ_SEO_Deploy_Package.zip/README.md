# RoofRFQ SEO & GEO — Quick Deploy Guide

## What's Included

```
roofrfq-seo/
├── netlify/
│   └── edge-functions/
│       └── seo-injector.ts    ← Edge function that auto-injects all SEO markup
├── public/
│   ├── robots.txt             ← Search engine crawler rules
│   └── sitemap.xml            ← Sitemap for Google/Bing indexing
├── netlify.toml               ← Netlify config (edge function routing + caching headers)
└── README.md                  ← This file
```

## How It Works

The **seo-injector** edge function intercepts every HTML page request and injects:
- Meta description, OG tags, Twitter cards, and geo tags into `<head>`
- Organization, Service, FAQ, and Speakable schema markup before `</body>`
- Page-specific meta for each URL (homepage, local pages, etc.)

This means **zero changes to your React/Next.js source code** — the edge function handles everything at the CDN level.

## Deploy in 3 Steps

### Step 1: Copy files to your GitHub repo

Copy these files into your RoofRFQ repo:

```bash
# From your repo root:
cp -r netlify/ ./netlify/
cp -r public/robots.txt ./public/robots.txt
cp -r public/sitemap.xml ./public/sitemap.xml
```

For `netlify.toml`: If you already have one, merge the contents. If not, copy it to your repo root.

### Step 2: Push to GitHub

```bash
git add .
git commit -m "feat: add SEO edge function, schema markup, sitemap, robots.txt"
git push origin main
```

### Step 3: Netlify auto-deploys

Netlify will automatically build and deploy once it detects the push. The edge function will immediately start injecting SEO markup into every page.

## Verify It's Working

After deploy, check:
1. **View source** on https://roofrfq.ca — you should see the schema markup before `</body>`
2. **Google Rich Results Test**: https://search.google.com/test/rich-results — paste your URL
3. **Schema Validator**: https://validator.schema.org/ — paste your URL
4. **Google Search Console** → submit sitemap at https://roofrfq.ca/sitemap.xml

## What's Already Set Up on Netlify

Environment variables have been configured:
- `NEXT_PUBLIC_SITE_URL` = https://roofrfq.ca
- `NEXT_PUBLIC_GA_MEASUREMENT_ID` = G-XXXXXXXXXX (replace with your real GA4 ID)
- `SEO_SCHEMA_VERSION` = 1.0.0

## Next Steps After Deploy

1. **Replace GA4 ID**: Update `NEXT_PUBLIC_GA_MEASUREMENT_ID` in Netlify env vars with your real Google Analytics 4 measurement ID
2. **Submit to Google Search Console**: Verify domain ownership and submit sitemap
3. **Submit to Bing Webmaster Tools**: https://www.bing.com/webmasters
4. **Create Google Business Profile**: List RoofRFQ with consistent NAP info
5. **Start publishing content**: Follow the content calendar in the strategy doc

## Updating SEO Markup

To update schema, meta tags, or add new local pages:
1. Edit `netlify/edge-functions/seo-injector.ts`
2. Add new entries to the `pageMeta` object for new URLs
3. Update schema objects as needed
4. Push to GitHub — Netlify redeploys automatically
